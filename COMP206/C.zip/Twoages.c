#include <stdio.h>
void main(int argc, char *argv[])
{
int age1, age2;
printf("Enter two ages: ");
scanf("%d %d", &age1, &age2);
if (age1 > age2)
printf("%d is larger than %d\n", age1, age2);
else if (age1 < age2)
printf("%d is larger than %d\n", age2, age1);
else
printf("age1 and age2 are equal\n");
}
