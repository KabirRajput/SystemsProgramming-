void uselessFunction(void);
