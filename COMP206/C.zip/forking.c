#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

#define MAX_COUNT 20
// change these to see what process finishes first, the greater
// the number the greater the delay to finish will be!
#define PARENT_DELAY 10000000
#define CHILD_DELAY 20

// fork() returns:
//		- negative value if unable to create child
//		- zero to a newly created child process
//		- positive value (process ID of type pid_t) to the parent


/*
***IMPORTANT***
The CPU will assign a small time for each process (one at the
time) this means that parent or child will run some time before
it gets switched to the other process. Therefor, the delay
must be significantly big so it doesn't finish within one
quanta of time.
*/
void  ChildProcess(void);
void  ParentProcess(void);


void  main(void)
{
     pid_t  pid;

     pid = fork();
     if (pid == 0) 
          ChildProcess();
     else 
          ParentProcess();
}

void  ChildProcess(void)
{
	printf("***ChildProcess started***\n");
	for (int i = 1; i <= (MAX_COUNT+CHILD_DELAY); i++);
   printf("*** Child process is done ***\n");
}

void  ParentProcess(void)
{
	printf("***ParentProcess started***\n");
	for (int i = 1; i <= (MAX_COUNT+PARENT_DELAY); i++);
   printf("*** Parent is done ***\n");
}

