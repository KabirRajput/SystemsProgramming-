// This program will prompt the user to input numbers repetively,
// the number will be stored in a dynamic list that will double
// in size. It will start with size 10.
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
  // The main difference between calloc() and malloc() is that calloc()
  // sets allocated memory to zero. So we can use either..
  printf("Hi! You'll be asked to type integers. Type \"done\" when you finished\n");
  char isDone[4];
  int *myDynamicList;
  myDynamicList = (int *) calloc(10, sizeof(int));
  int sizeOfList = 10;
  int counter = 0;

  while(1 == 1)                           // will loop until I call a break
  {
    printf("Please type an integer: ");
    scanf("%s", isDone);                  // treating every input as string
    int myNumber = atoi(isDone);          // if it's "done" then it won't work, but
                                          // it will return 0. Possible possible problem
                                          // here.
    if(strcmp(isDone, "done") == 0)
    {
      // so myNumber might be 0, if it's a 0 of atoi returning a input mismatch
      // then this will end the loop.
      break;
    }
    else
    {
        if(counter == (sizeOfList - 1))
        {
          sizeOfList = 2*sizeOfList;
          myDynamicList = (int *) realloc(myDynamicList, sizeOfList*(sizeof(int)));
          printf("List just doubled in size!\n");
          *(myDynamicList + counter) = myNumber;
          counter++;
        }
        else
        {
          *(myDynamicList + counter) = myNumber;
          counter++;
        }
    }
  }
  // I will print the array in a square, just to make it clean..
  printf("You typed %d integers, here they are: \n", counter);
  printf("[");
	for(int k = 0; k < counter; k++)
	{
		// the format of the print will be 10 by 10:
		if((k%10) == 9)
		{
			printf("%d \n", *(myDynamicList+k));
		}
		else
		{
      if(k == (counter-1))
      {
        printf("%d", *(myDynamicList+k));
      }
      else
      {
        printf("%d, ", *(myDynamicList+k));
      }
		}
	}
  printf("]");
	printf("\n");
  free(myDynamicList);
  return 0;
}
