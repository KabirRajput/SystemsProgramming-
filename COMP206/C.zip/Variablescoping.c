#include <stdio.h>
int x = 3;
int main() {
display(x);
x = 5;
display(x);
}

void display(int x) {
printf("%d",x);
}
