void printingStuff(void);
