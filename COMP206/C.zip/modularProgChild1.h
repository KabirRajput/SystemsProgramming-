void generateRandomClass(int, int *);
