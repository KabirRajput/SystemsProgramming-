/*
	modularProgChild1 will be included in modularProgParent, to do this
	we will write some functions and a global variable. We will compile
	it with switch -o to get modularProgChild1.o and finally we will create
	a file called modularProgChild1.h containing the function prototypes.
*/

// this code generates NUMBEROFSTUDENTS random results and stores it
// in an array called gradesOfClass.
#include<stdio.h>
#include<stdlib.h>
#include<time.h>

// I don't have the marks of the final, so let's make random exam results
// with this function.
void generateRandomClass(int NUMBEROFSTUDENTS, int *gradesOfClass)
{
	srand(time(NULL)); // to make random numbers..
	// the number of students will also be random, maximum of 100
	for(int i = 0; i < NUMBEROFSTUDENTS; i++)
	{
			*(gradesOfClass+i) = rand() % 100;
	}
}
