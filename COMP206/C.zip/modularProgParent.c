#include<stdio.h>
#include"modularProgChild1.h"
#include"modularProgChild2.h"
#define CURVE(students, curveSHIFT)            			\
   for(int i = 0; i < (students); ++i)	        		\
   {                                            		\
      gradesOfStudents[i] = gradesOfStudents[i] + (curveSHIFT);	\
   }

int averageOfClass(int, int*);

int main(int argc, char *argv[])
{
	int NUMBEROFSTUDENTS = 50;
	int gradesOfStudents[50];
	generateRandomClass(NUMBEROFSTUDENTS, gradesOfStudents);
	printf("Here are the grades of the class: \n");
	printGrades(NUMBEROFSTUDENTS, gradesOfStudents);
	//suppose that CS department requieres an average of 70
	//or they must curve up by 5 points.
	if(averageOfClass(NUMBEROFSTUDENTS, gradesOfStudents) < 70)
	{
		printf("but the average was below 70, so we curved up: ");
		CURVE(NUMBEROFSTUDENTS, 5);
		printGrades(NUMBEROFSTUDENTS, gradesOfStudents);
	}
	return 0;
}

int averageOfClass(int NUMBEROFSTUDENTS, int *ptr)
{
	int sum = 0;
	for(int j = 0; j < NUMBEROFSTUDENTS; j++)
	{
		sum = sum + *(ptr+j);
	} 
	int average = sum / NUMBEROFSTUDENTS;
	return average;
}
