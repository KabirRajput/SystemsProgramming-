void printGrades(int, int *);
