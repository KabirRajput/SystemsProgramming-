#include<stdio.h>

void uselessFunction(void)
{
	printf("We are in the file3.c, hi!\n");
}
