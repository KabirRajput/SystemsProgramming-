// this is a file that will be included in the directive.c
// program. You do not need to compile this file. However,
// keep it in the same directory.

#define printingTruth		\
	int joseph = 206;				\
	printf("Comp %d is the best class\n", joseph); 
