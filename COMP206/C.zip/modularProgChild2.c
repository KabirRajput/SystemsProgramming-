// This code is meant to display the results of the students.

#include<stdio.h>

void printGrades(int NUMBEROFSTUDENTS, int *gradesOfClass)
{
	printf("The results of the class are:\n");
	for(int k = 0; k < NUMBEROFSTUDENTS; k++)
	{
		// the format of the print will be 10 by 10:
		if((k%10) == 9)
		{
			printf("%d \n", gradesOfClass[k]);
		}
		else
		{
			printf("%d ", gradesOfClass[k]);
		}
	}
	printf("\n");
}
