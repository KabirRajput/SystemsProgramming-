#include<stdio.h>

// In C there is this very useful directive #define, here
// are some examples where #define makes code beautiful:
#define myName "sebastian"
#define myAge 21
#define lazyForLoop(max) for(int i=0; i<(max); i++)printf("hi\n");
#define LOOP(start, end)                  \
  for (int i = (start); i < (end); i++) { \
    printf("%d\n", i);                    \
  }
#define MAIN int main(int argc, char *argv[])
// As you can see from below, using the #define command makes
// the code really short and easy to read


// The #include directive can become handy if you want to make
// your code as consise as possible. Here is an example with
// a file called tobeIncluded.h file in the same directory:
#include"tobeIncluded.h"
// note that you do not need to compile your header.


// There is a conditional inclusion. Provides a way
// to include code selectively depending on the value of the
// condition. We have #ifdef(or #ifndef) NAME, #else, #endif
// if NAME is #define do...(if NAME is not #define do...)
#ifdef printingTruth											
	#define errorTest printf("tobeIncluded.h was indeed included\n");	
#else																
	#define errorTest printf("tobeIncluded.h was NOT included\n");		
#endif 		

// Finally, there is const.
const int x  = 2;
const char NEWLINE = '\n';

MAIN
{
	int x = myAge;
	char *y = myName;
	printf("my name is %s\n", y);
	printf("I am %d\n", x);
	lazyForLoop(5);
	LOOP(0,4);
	printingTruth;
	errorTest;
	printf("%c", NEWLINE);
	return 0;
}

