#include <stdio.h>
typedef int scalefactor;
int main() {
scalefactor a;
a = 10;
printf("The scale factor is:%d\n", a);
}
