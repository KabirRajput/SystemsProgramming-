#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define NUM_OF_PAR 3
#define ORIGINAL_FILE "TOPSECRET.txt"
#define NEW_FILE "TOPSECRET_COPY.txt"
#define ENCRYPTED_FILE "TOPSECRET_ENCRYPTED.txt"
#define SHIFT 6

int cmdlineArgumentCheck(int, char*[]);
void printDocument(void);
void makeCopyOfDocument(void);
void encryptDocument(void);
void listDirectory(void);

int main(int argc, char *argv[])
{
	if(cmdlineArgumentCheck(argc, argv) == 1) {
		return 1;
	}
	int parameter1 = atoi(argv[1]);
 	int parameter2 = atoi(argv[2]);
	// The first parameter is either 0 ( print document )
	// or not ( make copy of the original file )
	switch(parameter1) {
		case 0:
			printDocument();
			break;
		default:
			makeCopyOfDocument();
	}
	// The second paramenter:
	// 0 for encrypting the document
	// any other number to list the directory
	switch(parameter2) {
      case 0:
         encryptDocument();
         break;
      default:
         deleteDocument();
   }
}

void printDocument(void)
{
	FILE *fp;
	fp = fopen(ORIGINAL_FILE, "r");
	// The simpliest way to read a file is read it
	// char by char. So you can actually modify the
	// stream as you read it (later on with encryptDoc)
	char myChar;
	while((myChar = fgetc(fp)) != EOF)
	{
		printf("%c", myChar);
	}
	fclose(fp);
}

void makeCopyOfDocument(void)
{
	FILE *fp1, *fp2;
	fp1 = fopen(ORIGINAL_FILE, "r");
	fp2 = fopen(NEW_FILE, "w+");
	char myChar;
	while((myChar = fgetc(fp1)) != EOF)
	{
		fputc(myChar, fp2);
	}
	fclose(fp1);
	fclose(fp2);
}

void encryptDocument(void)
{
	FILE *fp1;
	FILE *fp2;
	fp1 = fopen(ORIGINAL_FILE, "r");
	fp2 = fopen(ENCRYPTED_FILE, "w+");
	char myChar;
	while((myChar = fgetc(fp1)) != EOF)
	{
		// only shift alphabetical chars
		if(((myChar > 64) && (myChar < 90)) || ((myChar > 96)&&(myChar < 122)))
		{
			myChar = myChar + SHIFT;
			fputc(myChar, fp2);
		}
		else
		{
			fputc(myChar, fp2);
		}
	}
	fclose(fp1);
	fclose(fp2);
}
void listDirectory(void)
{
	char command[50];
	strcpy( command, "ls -la");
	system(command);
}

int cmdlineArgumentCheck(int argc, char *argv[])
{
   // only run if 2 integers are passed, +1 for ./a.out
   if( argc != NUM_OF_PAR ) {
		printf("***PROGRAM NOT CALLED PROPERLY***\n");
		printf("You must pass 2 integers when calling this program\n");
      printf("for example: ./a.out 0 1\n");
      return 1;
   }
	// atoi will return 0 for any string that is not a number,
	// this could potentially be a problem.
	int parameter1 = atoi(argv[1]);
	int parameter2 = atoi(argv[2]);
	// strcmp return 0 only if strings are equal
	if((parameter1 == 0) && (strcmp(argv[1], "0") != 0 )) {
		printf("program not called properly\n");
		return 1;}
	if((parameter2 == 0) && (strcmp(argv[2], "0") != 0 )) {
		printf("program not called properly\n");
		return 1;}

	return 0;
}
