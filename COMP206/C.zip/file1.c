#include<stdio.h>
#include"file2.h"
#define MAIN int main(int argc, char *argv[])

MAIN {
	printf("We are in the main which is in file1.c\n");
	printf("We will make our first call to function in file2.c\n");
	printingStuff();
	printf("DONE!\n");
}
