// understading pointers in C
// Arrays and pointers are very similar, I recommend looking
// at Joseph's slides Week 6 slides 19 to 40. Here are some 
// examples of pointers manipulation

#include<stdio.h>

void incrementArray(int *);
void printArray(int *);
void swapPointers(int *, int *);
void replacingSpecificCharInString(int, int, char*, char *);


int main(int argc, char argv[])
{
	printf("TEST1-------------------------------------\n");
	// first way to initialize an array, this is completly
	// arbitrary choice:
	int genericArray[5] = {1, 3, 66, 32, 4};
	printArray(genericArray);
	printf("We will now increment each number by one, and print it from main \n");
	incrementArray(genericArray);
	printArray(genericArray);
	printf("\n");
	
	printf("TEST2-------------------------------------\n");
	// second way to initialize an array, again completly
	// arbitrary choice
	char str1[12];
	// this is 'bobTheHacker'
	str1[0]='b';str1[1]='o';str1[2]='b';str1[3]='T';str1[4]='h';
	str1[5]='e';str1[6]='H';str1[7]='a';str1[8]='c';str1[9]='k';
	str1[10]='e';str1[11]='r';
	printf("The original string was: %s\n", str1);
	printf("We want to modify the word \"Hacker\" to \"Fool\"\n");
	char *foolString = "fool";
	/*
	 *		[b, o, b, T, h, e, H, a, c, k, e, r  ]
	 *		 0, 1, 2, 3, 4, 5, 6, 7, 8 ,9, 10, 11
	 */
	// We need to replace chars between index 6 and 11
	replacingSpecificCharInString(6, 11, str1, foolString);
	printf("%s\n", str1);
	printf("\n");

	printf("TEST3-------------------------------------\n");
	// Finally let's see some swapping pointer action
	int a = 4;
	int b = 3;
	int *p1;
	int *p2;
	printf("Currently we have 2 defined varibles a=%d, and b=%d\n", a, b);
	// we can make our pointer point to a
	p1 = &a; // pointer points to address of a
	p2 = &b; // pointer points to address of b
	printf("we define 2 pointers p1 and p2 which point to a and b respectively\n");
	printf("the value of p1 is: %p\n", p1);
	printf("p1 is pointing to: %d\n", *p1);
	printf("the value of p2 is: %p\n", p2);
 	printf("p2 is pointing to: %d\n", *p2);
	printf("Now let's swap the pointers!\n");
	swapPointers(p1, p2);
	printf("the value of p1 is: %p\n", p1);
 	printf("p1 is pointing to: %d\n", *p1);
 	printf("the value of p2 is: %p\n", p2);
 	printf("p2 is pointing to: %d\n", *p2);	
	return 0;
}

// print an array of integers:
void printArray(int *arrayPointer)
{
	printf("Currently the array contains: {");
	for(int i = 0; i < 5; i++)
	{
		// Initially the array pointer points to the
		// first element, we have to increment the pointer
		// to it points to the next slot: 

		// the if-else is just there for formatting reasons
		if( i <= 3)
		{
			printf("%d, ", *(arrayPointer+i));
		}
		else
		{
			printf("%d", *(arrayPointer+i));	
		}
	}  
	printf("}\n");
}

// Increment the number of each slot by one
void incrementArray(int *arrayToIncrement)
{
	for(int i = 0; i < 5; i++)
	{
		*(arrayToIncrement+i)=*(arrayToIncrement+i)+1;	
	}
}


void swapPointers(int *ptr1, int *ptr2)
{
	// just like any swap, we need a tmp pointer so we don't
	// lose the value of one of the pointers

	// however you can't swap the actual pointers, you have to
	// swap the values pointed
	int tmpPtr;
	tmpPtr=*ptr2;
	*ptr2=*ptr1;
	*ptr1=tmpPtr;
}

// This functions will replace the char from index "start"
// to the word fool and erase the rest.
void replacingSpecificCharInString(int start, int end, char* originalStr, char* foolString)
{
	for(int i = 0; i < 4; i++)
	{
      *(originalStr+start)=*(foolString+i);
		start++;
	}
	while(start != end)
	{
		// all the other characters should be null
		*(originalStr+start) = '\0';
		start++;	
	}
}
