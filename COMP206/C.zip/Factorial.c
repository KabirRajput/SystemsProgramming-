#include <stdio.h>
#define N 0;

int factorial(int n) {
    int result=1;
    int i=1;
    while (i<=n) {
        result=result*i;
        i=i+1;
    }
    return result;
}

int main(int argc, char *argv[]) {
  printf("Factorial of %d is %d\n", 0, factorial(0));
  return 0;
}
