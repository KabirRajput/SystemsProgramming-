// Understanding scopes in C

#include<stdio.h>

/*	myGlobalInteger can be accesed by any function that is
	below it, this means that it's a global variable */
int myGlobalInteger = 4;

/* function prototype, they are necessary to call
	functions that are not positionally global to the others */
void myNotSoGlobalFunction(int, int);


//--------------------------------------------
// these two functions are accesible by the main
// because there were declera above it.
void somewhatGlobalFunction()
{
	myNotSoGlobalFunction(3,3);
}

void changeGlobalVariable(void)
{
	myGlobalInteger = 666;
}
//--------------------------------------------

int main(int argc, char *argv[])
{
	printf("The global variable is %d\n", myGlobalInteger);
	myGlobalInteger++; // we can modify the global variable from the main
	printf("The global variable now is %d\n", myGlobalInteger);
	changeGlobalVariable(); // you can change it from anywhere!
	printf("The global variable now is %d\n", myGlobalInteger);

	/* Functions protypes example, calling somewhatGlobalFunction*/
	somewhatGlobalFunction();

	return 0;
}

void myNotSoGlobalFunction(int x, int y)
{
	// Without the function prototypes, this function would not be
	// accessible to any function (only functions below it would be
	// able to call it).
	printf("This is brought you by function prototypes\n");
}

