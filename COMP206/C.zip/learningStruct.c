// This C file will explore Struct and Union
#include<stdio.h>
#include<string.h>

// Struct is a data structure that COMPOSES variables into a single RECORD
// Union is a data structure that MERGES into a single VARIABLE

// first way to define a struct:
struct human
{
	char name[20];
	int age;
	char gender;
}Mary;	// already creating a human called Marry

// second way to define a struct:
typedef struct cat
{
	int age;
	char color[20];
	char friendly;
} CATS;

int main(int argc, char *argv[])
{
	struct human Sebastian;	// making new human Sebastian
	struct human Bob;	// making new human called Bob
	// Here are how we initialize "members" of the structure
	strcpy(Sebastian.name, "sebastian");
	Sebastian.age = 21;
	Sebastian.gender = 'M';
	strcpy(Bob.name, "bob");
   Bob.age = 18;
   Bob.gender = 'M';
	strcpy(Mary.name, "mary");
   Mary.age = 21;
   Mary.gender = 'F';
	printf("Mary is %d years old\n", Mary.age);
	// Since we used typedef in the second way we do not need to
	// make a struct cat NAME statement.
	CATS Kepler;
	Kepler.age = 3;
	strcpy(Kepler.color, "ginger");
	Kepler.friendly = 'Y';
	
	printf("Completed successfully!\n");
	printf("My cat Kepler is %d years old, he is %s\n",Kepler.age, Kepler.color);
	return 0;
}
