#include<stdio.h>
#include"file3.h"

void printingStuff(void)
{
	printf("This is printing from file3, we call a function from file2\n");
	uselessFunction();
}
