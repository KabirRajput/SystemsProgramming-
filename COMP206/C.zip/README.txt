Hi!
Here are some small c examples about
subjects we learned in class.
Hope it can be useful!

This directory contains:
	1) scopes.c
	2) pointers.c
	3) directive.c
	4) modularProgParent.c
		|-- modularProgChild1.c
		|-- modularProgChild2.c
		Note that there is also modularProgChild1.h and modularProgChild2.h
	5) using make/makefile:
		 |-- file1.c
		 |-- file2.c
		 |-- file3.c
		 In this case, file1.c will need a function inside file2.c, and file2.c
		 needs a function in file3.c. You can already use make command and it will
		 compile in the right order!
	6) learningStruct.c
	7) fileIO.c
		|--- You need TOPSECRET.txt for this one
	8) forking.c
			Note that this file was greatly inspired by:
			http://www.csl.mtu.edu/cs4411.ck/www/NOTES/process/fork/create.html
			A good ressource in my opinion
	9) dynamicStorage.c

I followed the flow of the course, these are just some examples to make
it more clear.
