#!/bin/bash
echo "What is your name?"
read name
echo "Your name is $name."
echo 'Your name is $name.'