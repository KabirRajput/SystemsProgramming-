#!/bin/bash

factorial () {
        if [ $1 -eq 0 -o $1 -eq 1 ]; then
                echo 1
        else
                echo $(( $1 * $(factorial $(( $1 - 1 ))) ))
        fi
}

echo "Enter the number: "
read n

if [ $n -lt 0 ]; then
        echo "ERROR: The factorial of a negative number does not exist."
else
        echo "The factorial of $n is $(factorial $n)."
fi
