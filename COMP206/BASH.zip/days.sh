#!/bin/bash
echo 'Years:'
read age
x=`expr $age * 365`
echo $x
echo `expr $age * 365`
echo $(( $age * 365 ))