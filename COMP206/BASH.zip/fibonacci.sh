#!/bin/bash

fibonacci () {
        if [ $1 -eq 0 ]; then
                echo 0
        elif [ $1 -eq 1 -o $1 -eq 2 ]; then
                echo 1
        else
                echo $(( $(fibonacci $(( $1 - 2 ))) + $(fibonacci $(( $1 - 1 ))) ))
        fi
}

if [ $# -eq 0 ]; then
        echo "This program requires at least one argument."
        exit 1
else
        for a in $@
        do
                echo "Fibonacci of $a is $(fibonacci $a)"
        done
fi
